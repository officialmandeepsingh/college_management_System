
package cms;

public class CMS {
 public static void main(String[] args)
 {
        // TODO code application logic here
        projlogin obj=new projlogin();
        obj.setVisible(true);
    }
    
}
