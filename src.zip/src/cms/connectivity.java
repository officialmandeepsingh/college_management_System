package cms;

public interface connectivity
{
    public String URL="jdbc:mysql://localhost/mandeep";
    public String USER="root";
   public  String PASS="root";
}
